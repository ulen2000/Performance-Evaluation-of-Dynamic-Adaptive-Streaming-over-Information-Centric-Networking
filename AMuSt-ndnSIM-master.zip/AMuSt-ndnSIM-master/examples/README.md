Please refer to http://ndnsim.net/examples.html (../docs/source/examples.rst) 
for detailed information about the examples.

